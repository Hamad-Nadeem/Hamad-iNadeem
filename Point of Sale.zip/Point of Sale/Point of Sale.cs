﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Frontend_Page
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (richTextBox1.Text!="")
            {
                lblID.Text = "";
            }
            else
            {
                lblID.Hide();
            }
        }
        private void Clear()
        {
            ddlinvoice.Text = "";
            ddlname.Text = "";
            ddltype.Text = "";
            ddlprice.Text = "";
            ddldiscount.Text = "";
        }
        private void ddlprice_SelectedIndexChanged(object sender, EventArgs e)
        {
            int tableno = Convert.ToInt32(ddlprice.Text);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Customer_Bill obj = new Customer_Bill();
            obj.Show();
        }

        private void pictureBox4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("There are no device to Print your order","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
        }
    }
}